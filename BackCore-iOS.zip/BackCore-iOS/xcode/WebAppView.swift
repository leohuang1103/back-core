import SwiftUI
import UIKit
import WebKit
import UniformTypeIdentifiers

/// 用自訂網址 backcore://localhost/ 載入 App 內附的 index.html。
/// 網頁有固定的來源，localStorage（練習紀錄）才會穩定存在這支手機上。
struct WebAppView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.setURLSchemeHandler(context.coordinator, forURLScheme: "backcore")
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.userContentController.add(context.coordinator, name: "native")

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .systemBackground
        webView.scrollView.backgroundColor = .systemBackground
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsBackForwardNavigationGestures = false
        if #available(iOS 16.4, *) { webView.isInspectable = true }
        webView.load(URLRequest(url: URL(string: "backcore://localhost/index.html")!))
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    @MainActor
    final class Coordinator: NSObject, WKURLSchemeHandler, WKNavigationDelegate, WKScriptMessageHandler {

        // MARK: 提供 App 內附的檔案（index.html）
        func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
            guard let url = urlSchemeTask.request.url else {
                urlSchemeTask.didFailWithError(URLError(.badURL))
                return
            }
            var name = url.lastPathComponent
            if name.isEmpty || name == "/" { name = "index.html" }
            let ext = (name as NSString).pathExtension
            let base = (name as NSString).deletingPathExtension
            guard let fileURL = Bundle.main.url(forResource: base, withExtension: ext),
                  let data = try? Data(contentsOf: fileURL) else {
                urlSchemeTask.didFailWithError(URLError(.fileDoesNotExist))
                return
            }
            var mime = UTType(filenameExtension: ext)?.preferredMIMEType ?? "application/octet-stream"
            if mime.hasPrefix("text/") { mime += "; charset=utf-8" }
            let headers = ["Content-Type": mime, "Content-Length": String(data.count), "Cache-Control": "no-cache"]
            if let response = HTTPURLResponse(url: url, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: headers) {
                urlSchemeTask.didReceive(response)
            }
            urlSchemeTask.didReceive(data)
            urlSchemeTask.didFinish()
        }

        func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}

        // MARK: 外部連結（YouTube、參考網站）交給 YouTube App 或 Safari 開
        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if let url = navigationAction.request.url,
               let scheme = url.scheme?.lowercased(),
               scheme == "http" || scheme == "https",
               navigationAction.targetFrame?.isMainFrame ?? true {
                UIApplication.shared.open(url)
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }

        // MARK: 網頁傳來的訊息：觸覺回饋、計時時螢幕恆亮
        func userContentController(_ userContentController: WKUserContentController,
                                   didReceive message: WKScriptMessage) {
            guard message.name == "native", let body = message.body as? [String: Any] else { return }
            if let wake = body["wake"] as? Bool {
                UIApplication.shared.isIdleTimerDisabled = wake
            }
            if let haptic = body["haptic"] as? String {
                let generator = UIImpactFeedbackGenerator(style: .medium)
                generator.impactOccurred()
                if haptic == "double" {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    }
                }
            }
        }
    }
}
