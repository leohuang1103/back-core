import SwiftUI

@main
struct BackCoreApp: App {
    var body: some Scene {
        WindowGroup {
            WebAppView()
                .ignoresSafeArea()
                .background(Color(uiColor: .systemBackground))
        }
    }
}
