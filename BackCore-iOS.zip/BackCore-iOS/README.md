# Back Core 下背穩定跟練：iPhone 安裝說明

兩種裝法，二選一。

| | A. 網頁 App（加入主畫面） | B. 原生 App（Xcode） |
|---|---|---|
| 需要 | GitHub 帳號（免費） | Mac、Xcode、Apple ID |
| 離線使用 | 第一次開過之後可以 | 可以 |
| 紀錄存在 | 這支 iPhone | 這支 iPhone |
| 觸覺回饋 | 沒有（iPhone 網頁不支援震動） | 有 |
| 計時時螢幕恆亮 | 看 iOS 版本，不一定有 | 有 |
| 示範影片 | 可以在 App 裡直接播 | 開 YouTube App 播 |
| 維護 | 改版只要換 index.html | 免費帳號每 7 天要重裝一次 |

## A. 網頁 App（不用 Mac，推薦）

全程用 iPhone 就能做。先在「檔案」App 點這個壓縮檔解壓縮，pwa 資料夾裡有 7 個檔案（index.html、manifest.webmanifest、sw.js、4 個 icon png）。

1. **建 repo**：打開 GitHub App，按右上角 **＋ → Create repository**。名稱填 `back-core`，Visibility 選 **Public**，把 **Add a README** 打開，按 Create。
2. **上傳檔案**（App 做不到，用 Safari）：在 Safari 開 `https://github.com/你的帳號/back-core/upload/main`，點 **choose your files**，到「檔案」選取 pwa 資料夾裡的 7 個檔案（右上角「選取」可以一次選多個），往下按 **Commit changes**。
3. **開 Pages**：在 Safari 開 `https://github.com/你的帳號/back-core/settings/pages`，Source 選 **Deploy from a branch**，Branch 選 `main`、`/ (root)`，按 **Save**。畫面太擠的話，用網址列左邊的 **大小 → 切換為桌面版網站**。
4. 等一兩分鐘，網址是 `https://你的帳號.github.io/back-core/`。用 Safari 打開，按分享 → **加入主畫面**。
5. 之後從主畫面的 Back Core 圖示開啟，就是全螢幕 App，沒網路也能用。

注意：

- 紀錄存在手機裡。從主畫面刪掉 App，紀錄也會一起刪除。
- 頁面本身沒有任何個人資料，repo 設成 Public 沒關係。
- 之後改版時，到同一個 upload 網址上傳新的 `index.html` 覆蓋，下次有網路打開就會更新。

## B. 原生 App（需要 Mac）

1. Xcode → **File → New → Project → iOS → App**。Product Name 填 `BackCore`，Interface 選 **SwiftUI**，Language 選 **Swift**。
2. 用 `xcode` 資料夾裡的 `BackCoreApp.swift` 取代專案裡同名的檔案。再把 `WebAppView.swift` 和 `index.html` 拖進專案，勾選 **Copy items if needed** 和 BackCore target。原本的 `ContentView.swift` 可以刪掉。
3. 打開 **Assets → AppIcon**，把 `icon-1024.png` 拖進去。
4. 用線接上 iPhone，在 **Signing & Capabilities** 的 Team 選你的 Apple ID（Personal Team），按 **Run**。
5. iPhone 第一次安裝時：到「設定 → 隱私權與安全性」開啟**開發者模式**並重新開機；再到「設定 → 一般 → VPN 與裝置管理」信任你的開發者憑證。
6. 免費 Apple ID 簽的 App 7 天後會失效，接上 Mac 再按一次 Run 覆蓋安裝就好。不要先刪 App，紀錄就會保留。付費開發者帳號是一年。

這份 Swift 程式沒有在 Xcode 上編譯測試過。如果跳出錯誤，把錯誤訊息貼給我。

## 最快的替代方案

用 Safari 打開 claude.ai 上已發佈的版本，按分享 → 加入主畫面。不用架站，但需要網路、要登入 claude.ai，紀錄會同步到你的 Claude 帳號。
